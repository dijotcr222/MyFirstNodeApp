const express = require('express')
const app = express()
var sql = require('mssql')


var connection = {
    server: 'demodijo.database.windows.net',
    user: 'demo123',
    password: 'D1j0=0kRia123',
    database: 'myFirstSql',
    options: {
	       encrypt: true
	  }
};

sql.connect(connection, function (err) {
  if(err){
    console.log(err);
    console.log("Error in connection");
  }else{
    console.log("DB Connected");
  }
})


app.post('/senddata', function (req, res) {
    var SqlSt = "INSERT into chat (Token, OrderDate, Username, Name, City, State, PostalCode, Country, Total, TaxTotal) VALUES";
    SqlSt += util.format("(%s,%s,%s,%s,%s,%s,%s,%s,%d,%d)", token, date, req.body.name, req.body.email, req.body.City, req.body.State, req.body.PostalCode, req.body.Country, req.body.Total, req.body.TaxTotal );
    reqs.query(SqlSt, function(err, data){
        if(err){
          res.send(401, {"Message" : "Some Issue in saving data"})
        }else if(data){
          res.send(200, {"Message" : "Data Saved"});
        }
    });
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})
